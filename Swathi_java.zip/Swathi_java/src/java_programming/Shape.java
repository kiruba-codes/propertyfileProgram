package java_programming;

public abstract class Shape {
	String color;
//create abstract class
 public abstract double calculateArea();
 
 public void setColor(String color) {
	 this.color=color;
	 System.out.println(color);
 }
 

}

class circle extends Shape{

	@Override
	public double calculateArea() {
		double radius=5.0;
		double area=3.14*radius*radius;
		System.out.println(area);
		return area;
	}
	
	
}

class square extends Shape{

	@Override
	public double calculateArea() {
		double a=4.0;
		double area=a*a;
		System.out.println(area);
		return area;
	}
	
}