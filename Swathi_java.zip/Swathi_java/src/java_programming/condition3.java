package java_programming;

public class condition3 {

	public static void main(String[] args) {
   
		int i=1;
		//exit when i becomes greater then 4
	 do{
			//loop statements
			System.out.println("The value of i: "+i);
			//Increment the value of i for next iteration
			i++;
		}	while(i<=4);
	}

}
