package java_programming;

public interface Shapes {

	public double calculateArea();
	public double calculateVolume();
	

}
