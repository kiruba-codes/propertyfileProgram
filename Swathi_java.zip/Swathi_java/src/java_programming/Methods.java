package java_programming;

public class Methods {

		
			public static void method1() {
				System.out.println("im static method");
			}


}
