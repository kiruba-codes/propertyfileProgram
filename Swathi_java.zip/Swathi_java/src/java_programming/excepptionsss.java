package java_programming;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class excepptionsss {

	public static void main(String[] args) throws FileNotFoundException {
	
		FileInputStream fis=new FileInputStream("c://excelfile.xlsx");
	
	

	}
	
	
}
