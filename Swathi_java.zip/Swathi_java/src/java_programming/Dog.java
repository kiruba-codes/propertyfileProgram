package java_programming;

public class Dog extends Animal{
	
	
	public void eat() {
		super.eat();
		System.out.println("I can eat pedigree");
	}
	
	public void bark() {
		System.out.println("I can bark");
	}

}
