package java_programming;

public class ExceptionHandling {

	public static void main(String[] args) {
try {
	int d=5/0;
	
}
catch(ArithmeticException s)
{
System.out.println("Arithmetic exception handled: "+s.getMessage());	
}
	}

}
