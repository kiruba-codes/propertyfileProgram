package java_programming;

public class conditions {

	public static void main(String[] args) {

		//selection-if,if else,else if,switch 
		//iteration-while ,do while,for
		int a=3;

		if(a>5 && a<15) {
			
			System.out.println("a is greater than 5");
		}
		else if (a>15  && a<25)
		{
			System.out.println("a is greater than 15");
		}
		else if (a>25 ) {
			System.out.println("a is greater than 25");
		}
		else {
			System.out.println("a is less than 5");
		}
	}

}
