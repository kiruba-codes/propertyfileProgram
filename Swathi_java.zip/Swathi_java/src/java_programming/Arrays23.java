package java_programming;

import java.util.Arrays;

public class Arrays23 {

public Arrays23() {

	System.out.println("normal constructor");
}
public Arrays23(int a,int b,int d) {
	int c=a-b-d;
	System.out.println(c);
}
public static void main(String[]args) {
	Arrays23 a=new Arrays23(2,3,6);
	
}
}
