package java_programming;

import java.util.Scanner;

public class conditions2 {

	public static void main(String[] args) {
		  Scanner s=new Scanner(System.in);
		  System.out.println("Enter the Game");
		  String game=s.nextLine();
		  switch(game) {
		  case "cricket":
			  System.out.println("lets play cricket");
			  break;
		  case "baseball":
			  System.out.println("lets play baseball");
			  break;
		  case "hockey":
			  System.out.println("lets play hockey");
			  break;
		
			  default:
			  System.out.println("Its not a valid game");
		  }
	}

}
