package java_programming;

public class Circles implements Shapes {
double r=4.0;
	@Override
	public double calculateArea() {
Double area=3.14*r*r;
return area;
	}

	@Override
	public double calculateVolume() {
Double volume=(4/3)*3.14*r*r;
		return volume;
	}

	public static void main(String[]args) {
		Circles c=new Circles();
		c.calculateArea();
		c.calculateVolume();
			
	}
}
