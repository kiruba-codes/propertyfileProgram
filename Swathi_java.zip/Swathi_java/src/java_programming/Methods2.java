package java_programming;

public class Methods2 {


	public static void main(String[] args) {
Methods.method1();
	}

}
