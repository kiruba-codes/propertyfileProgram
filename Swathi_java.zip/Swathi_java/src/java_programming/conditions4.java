package java_programming;

import java.util.Scanner;

public class conditions4 {

		public static void main(String[] args) {
						System.out.println("Enter the name");
						Scanner s=new Scanner(System.in);
						String name=s.nextLine();
						System.out.println(name);
						int length=name.length();
						System.out.println(length);
						char arr[]=name.toCharArray();
						System.out.println(arr.length);
						for(int i=0;i<=arr.length-1;i++) {
							for(int j=0;j<=i;j++) {
								System.out.print(arr[i]);
							}
							System.out.println(" ");
						}
	}}

	