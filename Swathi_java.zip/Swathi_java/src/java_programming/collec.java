package java_programming;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class collec {

	public static void main(String[] args) {
		// Creating list using the ArrayList class
        List<Integer> numbers = new ArrayList<>();
        numbers.add(1);
        numbers.add(2);
        numbers.add(3);
        int num2=numbers.get(2);
        System.out.println(num2);
        numbers.remove(2);


	}

}
