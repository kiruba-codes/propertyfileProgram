package java_programming;

public class Conditions5 {

	public static void main(String[] args) {
		int rows=5;
		int number=1;
				for (int i=1;i<=rows;i++) {
																		for(int j=1;j<i+1;j++) {
																			
																			System.out.print(number++ + " ");
																			
																		}			
					System.out.println("");
				}
	}

}
