package java_programming;

import java.util.Scanner;

public class Sample {

						public static void main(String[]args) {
							
								Scanner s=new Scanner(System.in);
								
								System.out.println("Enter the value of a:");
								
								int a=s.nextInt();
								
								System.out.println("Enter the value of b:");
								
								int b=s.nextInt();
								
								int c=a+b;
								int d=a-b;
								int e=a*b;
								int f=a/b;
								
								System.out.println(c);
								System.out.println(d);
								System.out.println(e);

						}

}
