package java_programming;

public class arrays2 {

	public static void main(String[] args) {
int [][] numbers= {{2,3,4},
		                       {5,6,7},
		                       {8,9,10}};
System.out.println(numbers[0][0]);
	}

}
