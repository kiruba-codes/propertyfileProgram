package java_programming;

public class Main {

	public static void main(String[] args) {
//create the object of sub class
		Dog lab=new Dog();
		//access field of superclass

		lab.eat();
		lab.bark();
	}

}
