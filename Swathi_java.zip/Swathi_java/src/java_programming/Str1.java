package java_programming;



public class Str1{
	

  	public static void main(String[] args) {
  	   String name="volkswagen";
  	   StringBuffer s=new StringBuffer("Marvel");
  	   System.out.println(s.reverse());
  	  StringBuffer s2=new StringBuffer("volkswagen");
  	  System.out.println(s2.insert(5, "  swathi "));
  	  System.out.println(s2.delete(0, 6));
  	  System.out.println(s2.replace(0, 10, "marvel"));
  	  
  	   int length=name.length();
  	   System.out.println(name.substring(0, 5));
  	   System.out.println(name.replace('v', 'b'));
  	   System.out.println("The length of the string is: "+length);
  	  
  	   }

}
