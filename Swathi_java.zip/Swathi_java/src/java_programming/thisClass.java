package java_programming;

public class thisClass {
int variable=5;

void method(int variable) {
	variable=10;
	System.out.println("value of variable: "+this.variable);
	System.out.println("value of variable is: "+ variable);
	
}



void method() {
	int variable=40;
	System.out.println("value of variable: "+this.variable);

	System.out.println("value of variable: "+variable );
}




	public static void main(String[] args) {
thisClass c=new  thisClass();
c.method(30);
c.method();
	}

}
