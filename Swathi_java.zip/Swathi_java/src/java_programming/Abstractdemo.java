package java_programming;

public class Abstractdemo {

	public static void main(String[] args) {
circle c=new circle();
c.setColor("Red");
c.calculateArea();

square s=new square();
s.setColor("Green");
s.calculateArea();
	}

}
