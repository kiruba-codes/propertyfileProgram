package selenium;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TABS {
	public static void main(String[] args) throws IOException, InterruptedException {

	System.setProperty("webdriver.chrome.driver", "C:\\Users\\karth\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.rahulshettyacademy.com/AutomationPractice/");
	driver.findElement(By.id("opentab")).click();
	Actions action= new Actions(driver);
	Thread.sleep(4000);
	action.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).sendKeys(Keys.TAB).build().perform();}
}