package selenium;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DatadrivenTest {
	/*Data drivenlocatorValue 
	 * property file Handling-
	 * Excel file handling
	 * @dataprovider annotataion
	 * Database connectivity
	 */
	public WebDriver driver;
	public Datadriven datadriver;
	public Datadriven datafile;
	public String workingDir;
	
@BeforeTest
public void initiate() throws IOException {
	workingDir=System.getProperty("user.dir");
	datafile=new Datadriven(workingDir+"/Respository/data.properties");
	System.setProperty("webdriver.chrome.driver", "/home/kkirubakaran/Selenium/Selenium Jars/chromedriver_linux64/chromedriver");
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get(datafile.getData("url"));
}
@Test
public void login() throws Exception {
	//get object map file
	datadriver=new Datadriven(workingDir+"/Respository/locator.properties");
	//get the username element
	driver.findElement(datadriver.getLocator("username_field")).sendKeys(datafile.getData("username"));
	//get the password element
	driver.findElement(datadriver.getLocator("password_field")).sendKeys(datafile.getData("password"));
	//click on login button
	driver.findElement(datadriver.getLocator("login_button")).click();
	assertEquals("Hi, Demo User", driver.findElement(datadriver.getLocator("onlineuser")).getText());

}
	
}
