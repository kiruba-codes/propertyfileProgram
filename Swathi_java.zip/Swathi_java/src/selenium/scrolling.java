package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import jdk.jfr.Timespan;

public class scrolling {

	public static void main(String[] args) throws InterruptedException {
		//unconditional sync
		System.setProperty("webdriver.chrome.driver", "/home/kkirubakaran/Selenium/Selenium Jars/chromedriver_linux64/chromedriver");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.myntra.com/");
		//javascript executor
		WebElement men=driver.findElement(By.xpath("//*[@id=\"desktop-header-cnt\"]/div[2]/nav/div/div[1]/div/a"));
		//men.click();
		JavascriptExecutor js=((JavascriptExecutor)driver);
		//js.executescript(script,arguments);
		//js.executeScript("arguments[0].click()", men);
		js.executeScript("arguments[0].scrolltoView(true);",men);
		
	}

}
