package selenium;

import java.awt.Dimension;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import jdk.jfr.Timespan;

public class Sync {

	public static void main(String[] args) throws InterruptedException {
		//unconditional sync
		System.setProperty("webdriver.chrome.driver", "/home/kkirubakaran/Selenium/Selenium Jars/chromedriver_linux64/chromedriver");
		WebDriver driver=new ChromeDriver();
		Dimension d=new Dimension(420,600);
	
		driver.get("https://www.mycontactform.com/");
		driver.findElement(By.linkText("Sample Forms")).click();
		//condition sync
		//1.implicit-10sec
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

		//2.explicit wait
		WebDriverWait wait=new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("sample forms")));
		
		
	}

}
