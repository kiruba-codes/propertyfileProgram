package selenium;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Links {

	public static void main(String[] args) throws IOException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\karth\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.mycontactform.com/samples.php");
		
		List<WebElement> lists=driver.findElements(By.xpath(".//*[@id='left_col_top']/ul/li/a"));
		
		int a=lists.size();
		
		System.out.println("Total number of links: "+a);
		
		for (int i=1;i<a;i++) {
			List<WebElement> lists2=driver.findElements(By.xpath(".//*[@id='left_col_top']/ul["+i+"]/li/a"));
			int b=lists.size();
			for(int j=1;j<b;j++) {
				driver.findElement(By.xpath(".//*[@id='left_col_top']/ul["+i+"]/li["+j+"]/a")).click();
			}
		}
		
	}}
