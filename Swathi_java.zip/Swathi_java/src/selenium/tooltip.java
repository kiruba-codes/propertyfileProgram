package selenium;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class tooltip {
	static Properties p;
	public static String getData(String ElementName) {
		//read the value using the logical name as key
		String data=p.getProperty(ElementName);
		return data;
	}
	public static void main(String[] args) throws InterruptedException, IOException {
//		System.setProperty("webdriver.chrome.driver", "/home/kkirubakaran/Selenium/Selenium Jars/chromedriver_linux64/chromedriver");
//		WebDriver driver=new ChromeDriver();
//		driver.get("https://clarle.github.io/yui3/yui/docs/charts/charts-pie.html");
//		driver.manage().window().maximize();
//		Thread.sleep(3000);
//		WebElement purple=driver.findElement(By.xpath("//*[contains(@id,'yui_3_17_2_1_1625575704906_21')][contains(@class,'yui3-shape yui3-svgShape')][contains(@fill,'#66007f')]"));
//		purple.click();
//		WebElement tooltip=driver.findElement(By.xpath("//div[contains(@id,'yui_3_17_2_1_1625575704906_14_')][contains(@class,'yui3-chart-tooltip')]"));
//		System.out.println(tooltip.getText());
	String projectFolderpath=System.getProperty("user.dir");
		String property_filepath=projectFolderpath+"/Respository/data.properties";
		System.out.println(property_filepath);
		 p=new Properties(); 
		FileInputStream fis=new FileInputStream(property_filepath);
		p.load(fis);
		System.out.println(getData("url"));
		

		
	}

}
