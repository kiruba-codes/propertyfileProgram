package selenium;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;

public class Datadriven {
	/*Data driven
	 * property file Handling-
	 * Excel file handling
	 * @dataprovider annotataion
	 * Database connectivity
	 */
	Properties properties;
	public Datadriven(String filePath) throws IOException {
		FileInputStream locator=new FileInputStream(filePath);
		properties=new Properties();
		properties.load(locator);
	}
	public String getData(String ElementName) {
		//read the value using the logical name as key
		String data=properties.getProperty(ElementName);
		return data;
	}
	public By getLocator(String ElementName) throws Exception {
		//read the value using the logical name as key
		String locator=properties.getProperty(ElementName);
		//split the value which contains locator type and locator value
			String locatorType=locator.split(":")[0];
			String locatorValue=locator.split(":")[1];//swathi:java
			//return the instance of By class based on type
			if(locatorType.toLowerCase().equals("id"))
				return By.id(locatorValue);
			else if(locatorType.toLowerCase().equals("name"))
				return By.name(locatorValue);
		
			else if((locatorType.toLowerCase().equals("tagname")) 
				|| (locatorType.toLowerCase().equals("tag")))
				return By.tagName(locatorValue);
			else if((locatorType.toLowerCase().equals("linktext")) 
				|| (locatorType.toLowerCase().equals("link")))
				return By.linkText(locatorValue);
			else if((locatorType.toLowerCase().equals("classname")) 
					|| (locatorType.toLowerCase().equals("class")))
					return By.className(locatorValue);
			else if((locatorType.toLowerCase().equals("cssselector")) 
				|| (locatorType.toLowerCase().equals("css")))
				return By.cssSelector(locatorValue);
			else if(locatorType.toLowerCase().equals("xpath"))
				return By.xpath(locatorValue);
			else throw new Exception("Locator type '"+locatorType+"' not defined" );
			
			
			
			
			
			
	}}			
			