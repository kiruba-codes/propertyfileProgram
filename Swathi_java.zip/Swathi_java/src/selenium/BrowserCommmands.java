package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommmands {

	public static void main(String[] args) {
			//OPENING CHROME BROWSER
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\karth\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
			WebDriver d=new ChromeDriver();
			//opening a web==page sync time out---> ajax calls
			d.get("https://www.mycontactform.com/");
			d.manage().window().maximize();
//		System.out.println(	d.getTitle());
//			d.getCurrentUrl();
//			d.getPageSource();
//			d.navigate().back();
//			d.navigate().forward();
//			d.navigate().refresh();
			//locators
			/*id
			 * name
			 * class name
			 * link text
			 * partial link text
			 * xpath
			 * css selector*/
			
			d.findElement(By.linkText("Sample Forms")).click();
			
			//two types of xpath
			//relative-//atttribute details
			//absolute-/based oh html structure
			
			//tagname[@attribute name='attribute value']
			
			
			
	}

}
