package selenium;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Multipletabs {
	public static void main(String[] args) throws IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver", "/home/kkirubakaran/Selenium/Selenium Jars/chromedriver_linux64/chromedriver");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.rahulshettyacademy.com/AutomationPractice/");
		driver.findElement(By.id("openwindow")).click();
		ArrayList<String> tabs=new ArrayList<String>(driver.getWindowHandles());
		System.out.println(tabs.size());
		Thread.sleep(6000);
		driver.switchTo().window(tabs.get(0));
		System.out.println(driver.getTitle());
		Thread.sleep(6000);
		driver.switchTo().window(tabs.get(1));
		System.out.println(driver.getTitle());

		

		
}
}